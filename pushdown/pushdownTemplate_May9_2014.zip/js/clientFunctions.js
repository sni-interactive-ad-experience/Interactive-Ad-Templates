/*
	This file is the client specific content for the pushdown. It will automatically load in the pushdown template. To use follow these instructions
	1. Edit the clientVariables section below
	2. Edit the clientTracking section with your tracking tags, leave blank if you don't have them
	3. Edit the collapseStart, collapseDone, expandStart, expandDone functions with your animations (show/hide/move etc).
		a. collapseStart happens right when you click the collapse button
		b. collapseDone happens when the pushdown is done collapsing (approx 0.5 seconds after collapse start). 
		c. same for expandStart/expandDone
		d. Generally, put code in the start functions where you are removing elements, and put code in the done functions where you are showing new elements
	4. Change the firstViewCookie to be client specific (ex: "kraftApril"); 
	5. If using video set usingVideo to true
		a. If using a video you must setup your video using the videoFunctions.js file, and you have to set the link to in the videoFunctionsJSFile option, same with the Video CSS file

*/


///// tracking & config options /////

clientVariables = {
	debug: false, // True will auto-expand every time, and show console logs
	useCss3: true, // Use CSS3 transitions if supported
	collapseDelay: 8, // time until auto-collapse occurs, in seconds
	animationDuration: 0.5, // Animation expand/collapse speed, in seconds,
	firstViewCookie: "anotherTestCookie - change this for your project", //unique ID for cookie, must be unique for each client, can be anything you want
	
	/////// Configure below if using a video ////////
	usingVideo: true, //set to true if using video
	directory: "http://scrippsonline.com/risingStars/foodNetwork/pushdown/", //directory for your files, so if on adimages it would be http://adimages.scripps..../clientBaseFolder
	videoFunctionsJSFile: 'js/multiVideoFunctions_mod.js',
	videoCSSFile: 'css/videoStyles.css', //if you have a separate CSS file for your video player link it here, otherwise leave blank if the CSS for the video player is in your main CSS file
	trackingContainer: $('#pushdownTracking'), //this is the html <div> where tracking will get inserted, must much the ID you have in your HTML code
}
 
clientTracking = {
	expand: "", //put your expand 1x1 here
	expandStart: "",
	collapse: "", //put your collapse 1x1 here
	collapseStart: ""
}





/////////////////////////////////////////////// collapse functions - MODIFY inside each function ///////////////////////////////////////////////
function collapseStart(firstTime){
	if (clientVariables.debug){window.console.debug("start collapse");}
	
	/* this code simply moves the collapsed state down on collapse */
	if(firstTime !== true){
		$(".collapsedContainer").animate({
			top:0
		}, 500);
		$("#PushdownModule_button_expand").animate({
			top:0
		}, 500);
		$("#PushdownModule_button_collapse").animate({
			top:-66
		}, 500);
	}else{
		$("#PushdownModule_button_collapse").css("top","-66px");
	}
}

function collapseDone(){
	if (clientVariables.debug){window.console.debug("collapsed done");}
	//animate collapse state
	
}

//click events
$(".collapsedContainer").click(function(){
	window.open("","_blank");
});

/////////////////////////////////////////////// expand functions - MODIFY inside each function ///////////////////////////////////////////////
var initialExpand = false;
function startExpand(firstTime){
	if (clientVariables.debug){window.console.debug("start expand");}
	
	/* this code simply moves the collapsed state up on expand, change this if you don't want it to do that */
	if(firstTime === true){
		$(".collapsedContainer").css("top","-66px");
		$("#PushdownModule_button_expand").css("top","-66px");
		$("#PushdownModule_button_collapse").css("top","0px");
	}else{
		$(".collapsedContainer").animate({
			top: -66
		}, 500);
		$("#PushdownModule_button_expand").animate({
			top: -66
		}, 500);
		$("#PushdownModule_button_collapse").animate({
			top: 0
		}, 500);
	}
	initialExpand = firstTime;
}

function expandDone(){
	if (clientVariables.debug){window.console.debug("expand done");}
	//animate expanded elements
	
}


//click events
/*$(".expandContaniner").click(function(){
	window.open("","_blank");
});*/


///////////////////////////////// DON'T EDIT BELOW HERE /////////////////////////////////
// load in pushdown base file 
var script = document.createElement('script');
	script.type = "text/javascript";
	script.async = true;
	script.src = "http://adimages.scrippsnetworks.com/iax/_SharedFiles/_TEMPLATES/pushdown/pushdownBase.js";
	if (!script.addEventListener) {
		script.attachEvent('load', function (e) { loadedBase(); }, false);
	}else{
		script.addEventListener('load', function (e) { loadedBase(); }, false);
	}
	var addJSHere = document.getElementById("addJS");
	addJSHere.appendChild(script);
function loadedBase(){
	if (clientVariables.debug){window.console.debug("base loaded")}
	setupVariables();
	SNI.Ads.PushdownModule.init('#pd-wrap');
}

function setupVariables(){
	//set up variables
	$.each( clientVariables, function( key, value ) {
	  if (clientVariables.debug){window.console.debug( key + ": " + value )}
	  SNI.Ads.PushdownModule.config[key] = value;
	});
	//set up tracking
	$.each( clientTracking, function( key, value ) {
	  if (clientVariables.debug){window.console.debug( key + ": " + value )}
	  SNI.Ads.PushdownModule.tracking[key] = value;
	});
}