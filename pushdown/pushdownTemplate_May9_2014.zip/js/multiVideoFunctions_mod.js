if (typeof(SNI.Ads.multiVideoModule) === "undefined") {
  SNI.Ads.multiVideoModule = {};
}


SNI.Ads.multiVideoModule = {
	
		
	////////////////////////////////////////////////// Setup - MODIFY THESE OPTIONS //////////////////////////////////////////
		
	config:{
		debug: true, // True to show console logs/trace statements in firebug, false when doing final versions for traffic.
		startRandomVideo: true,
		//buttons below match the HTML from the videoPanel template. If you change something in the template change it here also
		btn: {
			activateAudio: $("#activateAudio"),
			replay: $("#replayVideo"),
			overVidInvis: $(".videoButton"), //large invisble button covering the whole video which you can click to pause the video when playing
			resumeVideo: $("#resumeVideo"),
			play: $(".jp-play"),
			pause: $(".jp-pause"),
			mute: $(".jp-mute"),
			unmute: $(".jp-unmute"),
			interface: $(".jPlayer_interface"), //container for all UI elements for video, large buttons and small buttons
			controlsContainer: $(".controlsContainer") //container for just the small buttons in the bottom right of video player
		},
		swfPath: "http://adimages.scrippsnetworks.com/iax/_SharedFiles/jPlayer/Jplayer.swf", //this is generic, don't need to modify
		videoModule: "#jPlayerVideoBox", // set this to match your video container box if you change it from default (default is #jPlayerVideoBox)
		videoSetup: {
			//need to supply mp4 and either webm or ogv, update the "videoFormates" with whatever files you types you provide
			videos: {
				video1: {
					m4v:"http://videos.scrippsnetworks.com/prerollads/sysco/Fresh_Factor_558x315.mp4",
					webm: "http://videos.scrippsnetworks.com/prerollads/sysco/Fresh_Factor_558x315.webm",
					poster: "http://scrippsonline.com/projectPreview/sysco/2014/PDSC/img/video1Poster.jpg",
					title: "QUALITY & VARIETY",
					copy: 'Watch as restaurant owners Anastasia and Michael Karloutsos chat with Chef Irvine about new dishes and the supplier they trust to deliver quality, gourmet ingredients to their restaurant.',
					CTAClick: "http://ad.doubleclick.net/ddm/clk/280345295;105913173;d?http://www.syscopossible.com/?tab=Specialty&utm_source=Food%20Network&utm_medium=Custom%20Pushdown&utm_campaign=IFS",
					videoPlay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_THE_FRESH_FACTOR_PLAY_AUDIO_1X1&adsize=1x1&PagePos=1",
					videoReplay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_THE_FRESH_FACTOR_REPLAY_1X1&adsize=1x1&PagePos=1"
				},
				video2: {
					m4v:"http://videos.scrippsnetworks.com/prerollads/sysco/Full_Service_558x315.mp4",
					webm: "http://videos.scrippsnetworks.com/prerollads/sysco/Full_Service_558x315.webm",
					poster: "http://scrippsonline.com/projectPreview/sysco/2014/PDSC/img/video2Poster.jpg",
					title: "BUSINESS REVIEW",
					copy: "Great food is just the beginning of a successful restaurant. Sysco offers a full suite of services and solutions to help you create and maintain a thriving business, from menu analysis and profitability control to business reviews and marketing tools.",
					CTAClick: "http://ad.doubleclick.net/ddm/clk/280345296;105913173;e?http://www.syscopossible.com/?tab=Business&utm_source=Food%20Network&utm_medium=Custom%20Pushdown&utm_campaign=IFS",
					videoPlay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_FULL_SERVICE_SOLUTION_PLAY_AUDIO_1X1&adsize=1x1&PagePos=1",
					videoReplay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_FULL_SERVICE_SOLUTION_REPLAY_1X1&adsize=1x1&PagePos=1"
				},
				video3: {
					m4v:"http://videos.scrippsnetworks.com/prerollads/sysco/The_Local_Difference_558x315.mp4",
					webm: "http://videos.scrippsnetworks.com/prerollads/sysco/The_Local_Difference_558x315.webm",
					poster: "http://scrippsonline.com/projectPreview/sysco/2014/PDSC/img/video3Poster.jpg",
					title: "LOCAL",
					copy: "Local equals fresh. Learn how Michael Karloutsos, owner of Water Works in Philadelphia, looks to Sysco for the best, farm-fresh produce grown right in his community.",
					CTAClick: "http://ad.doubleclick.net/ddm/clk/280346497;105913173;i?http://www.syscopossible.com/?tab=Local&utm_source=Food%20Network&utm_medium=Custom%20Pushdown&utm_campaign=IFS",
					videoPlay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_THE_LOCAL_DIFFERENCE_PLAY_AUDIO_1X1&adsize=1x1&PagePos=1",
					videoReplay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_THE_LOCAL_DIFFERENCE_REPLAY_1X1&adsize=1x1&PagePos=1"
				},
				video4: {
					m4v:"http://videos.scrippsnetworks.com/prerollads/sysco/Eyes_on_Supply_558x315.mp4",
					webm: "http://videos.scrippsnetworks.com/prerollads/sysco/Eyes_on_Supply_558x315.webm",
					poster: "http://scrippsonline.com/projectPreview/sysco/2014/PDSC/img/video4Poster.jpg",
					title: "SOTF",
					copy: "From the finest linens to the most durable ovens, nothing keeps your business running smooth like quality supplies and equipment. Even better is ordering it all online and having it delivered right to your door. ",
					CTAClick: "http://ad.doubleclick.net/ddm/clk/280346501;105913173;u?http://www.syscopossible.com/?tab=Supplies&utm_source=Food%20Network&utm_medium=Custom%20Pushdown&utm_campaign=IFS",
					videoPlay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_AN_EYE_ON_SUPPLY_PLAY_AUDIO_1X1&adsize=1x1&PagePos=1",
					videoReplay:"http://adsremote.scrippsnetworks.com/image.ng/site=FOOD&adtype=TRACKING&TRACKING=FOOD_14MAR12_SYSCO_PUSHDOWN_SHOWCASE_AN_EYE_ON_SUPPLY_REPLAY_1X1&adsize=1x1&PagePos=1"
				}
			},
			poster: $("#jp_poster_0"),
			videoFormats: "m4v, webmv", //change to match whichever formats you provided
			startMuted: true, //leave as true unless you don't want the video on the first panel to auto-play muted
			width: 558, //width of your video - make sure to change in the videoStyles.css file also
			height: 315, //height of your video - make sure to change in the videoStyles.css file also
			volume: 1 //0 - 1, decimal points allowed
		}
	},
	vars:{
		startUnmute: true, //set this if start with audio unmuted, otherwise set to false;
		firstUnmute: true,
		videoPlaying: false,
		videoEnded: false,
		clickedControlbar: false,
		whichVideo: "video1",
		currentVideo: "video1",
		numVideos: 0,
		posterCounter: 0,
		isTouchDevice: false,
		isMSIE: /*@cc_on!@*/0,
		clickURL: "",
		videoThumbnails: $(".videoOptions .thumb"), //if you change the class of the thumbnail in HTML change it here also
		videoTitle : $(".videoInfo .videoTitle"), //if video has title that will swap out, specify the title <div> here
		videoCopy : $(".videoInfo .videoCopy"), //if video has copy/caption that will swap out, specify the copy <div> here
		videoCTA : $(".videoInfo .seeMoreBtn") //if video has unique CTA, specify the CTA button here
	},
	
	
	////////////////////////////////////////////////// Functionality - DON'T MODIFY BELOW HERE //////////////////////////////////////////
	
	
	init: function() {
		var _self = SNI.Ads.multiVideoModule;
		if (_self.config.debug) {
			window.console.debug("initiate video player module");
		}
		
		// Check ios devices
		if ("ontouchstart" in document.documentElement){
			_self.vars.isTouchDevice = true;
		}else{
			_self.vars.isTouchDevice = false;
		}
		
		_self.vars.startUnmute = _self.config.videoSetup.startMuted;
		
		//load in player html code - HTML code is in the jplayer base files on adimages if needed
		$("#videoBox").append(videoHTML);

		//detect number of videos provided
    	for(var i in _self.config.videoSetup.videos)
       		if(_self.config.videoSetup.videos.hasOwnProperty(i))
            	_self.vars.numVideos++;
		if (_self.config.debug) { window.console.debug("number of videos is " + _self.vars.numVideos); }
		if(_self.vars.numVideos > 1){
			//start on a random video
			if(_self.config.startRandomVideo){
				_self.vars.whichVideo = "video" + Math.floor((Math.random()*_self.vars.numVideos)+1);
				if (_self.config.debug) { window.console.debug("starting on random video, video is " + _self.vars.whichVideo); }
			}else{
				if (_self.config.debug) { window.console.debug("starting on first video"); }	
			}
		}
		
		//initially load the player with the first video
		_self.loadVideo(_self.vars.whichVideo, false);
		
		//setup buttons again
			_self.config.btn.activateAudio = $("#activateAudio"); 
			_self.config.btn.replay = $("#replayVideo");
			_self.config.btn.overVidInvis = $(".videoButton"); //large invisble button covering the whole video which you can click to pause the video when playing
			_self.config.btn.resumeVideo = $("#resumeVideo");
			_self.config.btn.play = $(".jp-play");
			_self.config.btn.pause = $(".jp-pause");
			_self.config.btn.mute = $(".jp-mute");
			_self.config.btn.unmute = $(".jp-unmute");
			_self.config.btn.interface = $(".jPlayer_interface"); //container for all UI elements for video, large buttons and small buttons
			_self.config.btn.controlsContainer = $(".controlsContainer"); //co
		
		// activate buttons
		setTimeout(function(){
			_self.playerBtns();
		},1000);
		
		//if user navigates away from browser window to another program or a different page pause video
		if (_self.vars.isMSIE){
			// if using Internet Explorer do it this way, else use jQuery
			var activeElement;
			function pageLoad() {
				activeElement = document.activeElement;
				document.onfocusout = logWindow;
			}
			pageLoad();
		
			function logWindow() {
				if (activeElement !== document.activeElement) {
					activeElement = document.activeElement;
				}
				else {
					_self.onBlur();
				}
			}
		} else {
			$(window).blur(_self.onBlur);
		}
		
		if(_self.vars.isTouchDevice){
			_self.config.btn.activateAudio.hide();
			_self.hideControls();
			_self.config.btn.resumeVideo.show();
		}
		
		//check if video is still in view
		_self.isVisible();
		window.onscroll = function(){
			if(!$(_self.config.videoModule).visible("complete") && _self.vars.videoPlaying === true){
				_self.pauseVideo();
			}
		}
	},
	
	loadVideo: function(newVideo, shouldPlay){
		var _self = SNI.Ads.multiVideoModule;
		
		//setup poster image
		_self.config.videoSetup.poster = "#jp_poster_" + _self.vars.posterCounter;
		_self.vars.posterCounter++;
		
		_self.vars.currentVideo = newVideo
				
		$(_self.config.videoModule).jPlayer({
			ready: function () {
				$(this).jPlayer("setMedia", {
					m4v: _self.config.videoSetup.videos[newVideo].m4v,
					webmv: _self.config.videoSetup.videos[newVideo].webm,
					ogv: _self.config.videoSetup.videos[newVideo].ogv,
					poster: _self.config.videoSetup.videos[newVideo].poster
				});//.jPlayer("play"); //Attempts to Auto-Play the media
				//console.log("player set");
			},
			ended: function(videoEnded) { // The video ended, execute this function
				_self.vars.videoEnded = true;
				_self.vars.videoPlaying = false;
				$(_self.config.videoSetup.poster).show();
				_self.config.btn.activateAudio.hide();
				_self.config.btn.replay.show();
				_self.config.btn.overVidInvis.hide();
				_self.hideControls();
				if (_self.config.debug) {
					window.console.debug("large video ended");
				}
			},
			swfPath: _self.config.swfPath, //location of backup swf file for flash fallback
			supplied: _self.config.videoSetup.videoFormats,
			preload: "auto",
			volume: _self.config.videoSetup.volume,
			muted: _self.config.videoSetup.startMuted,
			wmode:"transparent",
			//nativeSupport: false,
			size: {
				width: _self.config.videoSetup.width,
				height: _self.config.videoSetup.height
			}
		});
		
		if(_self.vars.isTouchDevice && shouldPlay){
			_self.startVideo();
		}else if(_self.vars.isTouchDevice === false && shouldPlay){
			setTimeout(function(){_self.resumeVideo();},500);
		}else if(shouldPlay === false){
			SNI.Ads.PushdownModule.config.videoReady = true;	
		}
		
		//tracking video play
		if(!_self.vars.startUnmute){ 
			_self.doTracking(_self.config.videoSetup.videos[newVideo].videoPlay);	
		}
		
		//if using multiple videos
		if(_self.vars.numVideos > 1){
		  //add now playing class to active thumb
			var activeThumb = "#" + newVideo;
			$(activeThumb).addClass("nowPlaying");
			
		  //if using titles/copy/CTA that swap
			if(_self.config.videoSetup.videos[newVideo].title){
				_self.vars.videoTitle.fadeOut(300);
				setTimeout(function(){
					_self.vars.videoTitle.text(_self.config.videoSetup.videos[newVideo].title);
				},400);
				_self.vars.videoTitle.delay(500).fadeIn(300);
			}
			if(_self.config.videoSetup.videos[newVideo].copy){
				_self.vars.videoCopy.fadeOut(300);
				setTimeout(function(){
					_self.vars.videoCopy.text(_self.config.videoSetup.videos[newVideo].copy);
				},400);
				_self.vars.videoCopy.delay(500).fadeIn(300);
			}
			if(_self.config.videoSetup.videos[newVideo].CTAClick){
				_self.vars.videoCTA.fadeOut(300);
				setTimeout(function(){
					_self.vars.clickURL = _self.config.videoSetup.videos[newVideo].CTAClick;
				},400);
				_self.vars.videoCTA.delay(500).fadeIn(300);
			}
		}			
			
			
		
	},
	
	playerBtns: function(){
		var _self = SNI.Ads.multiVideoModule;
								
		if (_self.config.debug) {
			window.console.debug("activate video player buttons");
		}		
		
		//activate audio
		_self.config.btn.activateAudio.click(function(){
			if (_self.config.debug) {
				window.console.debug("play audio button clicked");
			}
			$(_self.config.videoModule).jPlayer("play",0); //restarts video
			$(_self.config.videoModule).jPlayer("unmute"); //unmutes
			$(this).hide();
			_self.config.btn.unmute.show(); //show little control buttons
			_self.vars.startUnmute = false;
			_self.vars.videoPlaying = true;
			_self.config.videoSetup.startMuted = false;
			_self.doTracking(_self.config.videoSetup.videos[_self.vars.currentVideo].videoPlay);	
		});
		
		//resume video
		_self.config.btn.resumeVideo.click(function(){
			_self.resumeVideo();
		});
		
		//replay video
		_self.config.btn.replay.click(function(){
			$(this).hide();
			$(_self.config.videoModule).jPlayer("play",0);
			$(_self.config.videoModule).jPlayer("unmute");
			$(_self.config.videoSetup.poster).hide();
			_self.config.btn.overVidInvis.show();
			_self.showControls();
			_self.vars.videoPlaying = true;
			_self.vars.videoEnded = false;
			if (_self.config.debug) {
				window.console.debug("replay button clicked");
			}
			//track video replay
			_self.doTracking(_self.config.videoSetup.videos[_self.vars.currentVideo].videoReplay);		
		});
		
		//pause video on click
		_self.config.btn.overVidInvis.click(function(){
			_self.pauseVideo();
		});
		_self.config.btn.pause.click(function(){
			_self.pauseVideo();
			_self.vars.clickedControlbar = true;
		});
		
		//add controlbar click to pause function
		_self.config.btn.mute.click(function(){
			_self.vars.clickedControlbar = true;
		});
		_self.config.btn.unmute.click(function(){
			_self.vars.clickedControlbar = true;
		});
		
		//show/hide controlbar on mouseout
		_self.config.btn.interface.mouseleave(function(){
			if((_self.vars.videoEnded === false)&&(_self.vars.videoPlaying === true)){
				if(_self.vars.isMSIE !== true){
					_self.hideControls();
				}
			}
		});
		_self.config.btn.interface.mouseenter(function(){
			if((_self.vars.videoEnded === false)&&(_self.vars.videoPlaying === true)&&(_self.vars.startUnmute !== true)){
				if(_self.vars.isMSIE !== true){
					_self.showControls();
				}
			}
		});
		
		//swap video on button clicks
		_self.vars.videoThumbnails.click(function(){
			if (_self.config.debug) {window.console.debug("video thumbnail clicked, swap player");}
			$(_self.config.videoModule).jPlayer("destroy"); //kill current video player					
			whichVideo = $(this).attr("ID"); //get ID of thumb to determine new video			
			/*setTimeout(function(){
				_self.loadVideo(whichVideo, true); //add new video
			},100);*/
			_self.loadVideo(whichVideo, true); //add new video
			//remove now playing from other icons
			var activeThumb = $(this).siblings(".nowPlaying").attr("ID");
			$("#" + activeThumb).removeClass("nowPlaying");
		});
		
	},
	
	showControls: function(){
		var _self = SNI.Ads.multiVideoModule;
		_self.config.btn.controlsContainer.show();
	},
	hideControls: function(){
		var _self = SNI.Ads.multiVideoModule;
		_self.config.btn.controlsContainer.hide();
		_self.config.btn.controlsContainer.fadeOut(0);
	},
	
	pauseVideo: function(){
		var _self = SNI.Ads.multiVideoModule;
		if (_self.config.debug) {
			window.console.debug("pause video function fired");
		}

		if(_self.vars.videoPlaying === true){
			$(_self.config.videoModule).jPlayer("pause");
			_self.vars.videoPlaying = false;
		}
		if(_self.vars.videoEnded === true){
			_self.config.btn.replay.show();
			_self.config.btn.resumeVideo.hide();
		}else{
			_self.config.btn.replay.hide();
			_self.config.btn.resumeVideo.show();
		}
		_self.config.btn.activateAudio.hide();
		_self.hideControls(); //hide the control bar when video is paused
		_self.config.btn.overVidInvis.hide(); //hide full video button	
	},
	
	resumeVideo: function(){
		var _self = SNI.Ads.multiVideoModule;
		if (_self.config.debug) {
			window.console.debug("resume video");
		}
		if(_self.vars.startUnmute){
			$(_self.config.videoModule).jPlayer("play",0);
			$(_self.config.videoSetup.poster).hide(); // if collapsed after video end hide poster image
			_self.doTracking(_self.config.videoSetup.videos[_self.vars.currentVideo].videoPlay);	
		}else{
			$(_self.config.videoModule).jPlayer("play");
			$(_self.config.videoSetup.poster).hide(); // if collapsed after video end hide poster image
		}
		_self.vars.videoPlaying = true;
		_self.vars.videoEnded = false;
		_self.vars.startUnmute = false;
		_self.showControls(); //show controls
		_self.config.btn.overVidInvis.show(); //show full video button
		_self.config.btn.activateAudio.hide();
		_self.config.btn.resumeVideo.hide();
		_self.config.btn.replay.hide();
		$(_self.config.videoModule).jPlayer("unmute");
		_self.config.btn.mute.show();
		_self.config.btn.pause.show(); //show little control buttons
		_self.config.btn.unmute.hide();
		_self.config.btn.play.hide();
		setTimeout(_self.hideControls,2000);
	},
	
	startVideo: function(){
		var _self = SNI.Ads.multiVideoModule;
		if (_self.config.debug) {
			window.console.debug("start video for first time");
		}
		_self.vars.startUnmute = true;
		if(_self.vars.isTouchDevice === true){
			_self.config.btn.resumeVideo.show();
			(_self.config.videoSetup.poster).show();
			console.log("ipad video start");
		}else{
			$(_self.config.videoModule).jPlayer("play",0);
			_self.vars.videoPlaying = true;
			_self.vars.videoEnded = false;
			_self.showControls(); //show controls
			_self.config.btn.overVidInvis.show(); //show full video button
			_self.config.btn.resumeVideo.hide();
			_self.config.btn.replay.hide();
			_self.config.btn.pause.show(); //show little control buttons
			_self.config.btn.play.hide();
			if(_self.config.videoSetup.startMuted){
				_self.config.btn.activateAudio.show();
				$(_self.config.videoModule).jPlayer("mute");
				_self.config.btn.unmute.show();
				_self.config.btn.mute.hide();
			}else{
				_self.config.btn.activateAudio.hide();
				$(_self.config.videoModule).jPlayer("unmute");
				_self.config.btn.mute.show();
				_self.config.btn.unmute.hide();
			}
			if(_self.vars.isMSIE !== true){
				setTimeout(_self.hideControls,2000);
			}
		}	
	},
	
	//pause on page lose focus
	onBlur: function() {
		var _self = SNI.Ads.multiVideoModule;
		if (_self.config.debug) {
			window.console.debug("pause video because page lost focus");
		}
		if((_self.vars.videoPlaying === true)&&(_self.vars.videoEnded === false)){
			_self.pauseVideo();
		}
	},
	doTracking: function(tag){
		var cacheBuster = (new Date()).getTime();
		var $body = clientVariables.trackingContainer;
		var $tracker = $('#dynamic-tracking');
	
		// Select or create tracking image
		if( $tracker.length > 0 ) {
			$tracker.attr('src', tag.replace(/$random$/, cacheBuster) + '&cb=' + cacheBuster);
		} else {
			$tracker = $('<img/>');
			$tracker.attr('id', "dynamic-tracking" + Math.floor((Math.random()*10000)+1));
			$tracker.attr('src', tag.replace(/$random$/, cacheBuster) + '&cb=' + cacheBuster);
			$tracker.css({"display":"none"});
			$body.append($tracker);
		}
	},
	isVisible: function(){
		var $w = $(window);
		$.fn.visible = function(partial,hidden,direction){
	
			if (this.length < 1)
				return;
	
			var $t        = this.length > 1 ? this.eq(0) : this,
				t         = $t.get(0),
				vpWidth   = $w.width(),
				vpHeight  = $w.height(),
				direction = (direction) ? direction : 'both',
				clientSize = hidden === true ? t.offsetWidth * t.offsetHeight : true;
	
			if (typeof t.getBoundingClientRect === 'function'){
	
				// Use this native browser method, if available.
				var rec = t.getBoundingClientRect(),
					tViz = rec.top    >= 0 && rec.top    <  vpHeight,
					bViz = rec.bottom >  0 && rec.bottom <= vpHeight,
					lViz = rec.left   >= 0 && rec.left   <  vpWidth,
					rViz = rec.right  >  0 && rec.right  <= vpWidth,
					vVisible   = partial ? tViz || bViz : tViz && bViz,
					hVisible   = partial ? lViz || lViz : lViz && rViz;
	
				if(direction === 'both')
					return clientSize && vVisible && hVisible;
				else if(direction === 'vertical')
					return clientSize && vVisible;
				else if(direction === 'horizontal')
					return clientSize && hVisible;
			} else {
	
				var viewTop         = $w.scrollTop(),
					viewBottom      = viewTop + vpHeight,
					viewLeft        = $w.scrollLeft(),
					viewRight       = viewLeft + vpWidth,
					offset          = $t.offset(),
					_top            = offset.top,
					_bottom         = _top + $t.height(),
					_left           = offset.left,
					_right          = _left + $t.width(),
					compareTop      = partial === true ? _bottom : _top,
					compareBottom   = partial === true ? _top : _bottom,
					compareLeft     = partial === true ? _right : _left,
					compareRight    = partial === true ? _left : _right;
	
				if(direction === 'both')
					return !!clientSize && ((compareBottom <= viewBottom) && (compareTop >= viewTop)) && ((compareRight <= viewRight) && (compareLeft >= viewLeft));
				else if(direction === 'vertical')
					return !!clientSize && ((compareBottom <= viewBottom) && (compareTop >= viewTop));
				else if(direction === 'horizontal')
					return !!clientSize && ((compareRight <= viewRight) && (compareLeft >= viewLeft));
			}
		};

	}
	
};







	


